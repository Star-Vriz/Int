-- Database: Aplikasi Perpustakaan Digital Sekolah
CREATE DATABASE IF NOT EXISTS perpustakaan
  DEFAULT CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE perpustakaan;

CREATE TABLE IF NOT EXISTS admin (
  id_admin INT(11) NOT NULL AUTO_INCREMENT,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL,
  nama_admin VARCHAR(50) NOT NULL,
  PRIMARY KEY (id_admin)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS anggota (
  id_anggota INT(11) NOT NULL AUTO_INCREMENT,
  nis VARCHAR(20) NOT NULL,
  nama_anggota VARCHAR(50) NOT NULL,
  username VARCHAR(50) NOT NULL,
  password VARCHAR(50) NOT NULL,
  kelas VARCHAR(35) NOT NULL,
  PRIMARY KEY (id_anggota)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS buku (
  id_buku INT(11) NOT NULL AUTO_INCREMENT,
  judul_buku VARCHAR(100) NOT NULL,
  pengarang VARCHAR(100) NOT NULL,
  penerbit VARCHAR(100) NOT NULL,
  tahun_terbit YEAR(4) NOT NULL,
  status ENUM('tersedia','tidak') NOT NULL,
  PRIMARY KEY (id_buku)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transaksi (
  id_transaksi INT(11) NOT NULL AUTO_INCREMENT,
  id_anggota INT(11) NOT NULL,
  id_buku INT(11) NOT NULL,
  tgl_pinjam DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  tgl_kembali DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status_transaksi ENUM('Peminjaman','Pengembalian') NOT NULL,
  PRIMARY KEY (id_transaksi),
  KEY idx_transaksi_anggota (id_anggota),
  KEY idx_transaksi_buku (id_buku),
  CONSTRAINT fk_transaksi_anggota FOREIGN KEY (id_anggota)
    REFERENCES anggota (id_anggota) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_transaksi_buku FOREIGN KEY (id_buku)
    REFERENCES buku (id_buku) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- Data admin awal (username: admin, password: admin)
INSERT INTO admin (username, password, nama_admin)
SELECT 'admin', 'admin', 'Administrator Perpustakaan'
WHERE NOT EXISTS (SELECT 1 FROM admin WHERE username = 'admin');
