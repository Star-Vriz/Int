# Aplikasi Perpustakaan Digital Sekolah

Aplikasi web sederhana (PHP native + MySQL + Tailwind CSS CDN) untuk UKK SMK RPL.
Fitur yang tersedia: **Login Admin, Dashboard, Logout**.

## Struktur
```
perpustakaan/
├── koneksi.php
├── login-admin.php
├── admin/
│   ├── dashboard.php
│   └── logout.php
└── database/
    └── perpustakaan.sql
```

## Cara Menjalankan
1. Jalankan **Apache** dan **MySQL** di XAMPP.
2. Salin folder `perpustakaan` ke `C:\xampp\htdocs\`.
3. Buka `http://localhost/phpmyadmin`, klik tab **Import**, pilih `database/perpustakaan.sql`, lalu **Import**.
4. Buka `http://localhost/perpustakaan/login-admin.php`.

## Akun Admin
| Username | Password |
|----------|----------|
| admin    | admin    |

## Catatan
- Butuh internet (Tailwind CDN dan Google Fonts).
- Jika nama database/folder diganti, sesuaikan `$database` di `koneksi.php`.
- Proyek ini untuk pembelajaran: password disimpan plaintext dan query login belum memakai prepared statement.
